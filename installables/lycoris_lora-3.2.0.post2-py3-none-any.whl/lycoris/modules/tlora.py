# lycoris/modules/tlora.py
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import copy

from .base import LycorisBaseModule
from ..functional import tlora as F_tlora

from typing import Optional

class TLoraModule(LycorisBaseModule):
    name = 'tlora'
    support_module = {
        "linear",
        "conv2d",
    }
    weight_list = [
        "lora_p.weight",
        "lora_q.weight",
        "lora_lambda",
        "base_q_weight",
        "base_p_weight",
        "base_lambda",
        "alpha",
    ]
    weight_list_det = ["lora_p.weight", "lora_q.weight"]

    def __init__(
        self,
        lora_name,
        org_module: nn.Module,
        multiplier=1.0,
        lora_dim=4,
        alpha=1,
        dropout=0.0,
        rank_dropout=0.0,
        module_dropout=0.0,
        use_tucker=False,
        use_scalar=False,
        rank_dropout_scale=False,
        weight_decompose=False,
        wd_on_output=False,
        bypass_mode=None,
        rs_lora=False,
        ggpo_beta: Optional[float] = None,
        ggpo_sigma: Optional[float] = None,
        ggpo_conv: bool = False,
        ggpo_conv_weight_sample_size: int = 100,
        sig_type="last",
        min_rank=1,
        **kwargs,
    ):
        super().__init__(
            lora_name,
            org_module,
            multiplier,
            dropout,
            rank_dropout,
            module_dropout,
            rank_dropout_scale,
            bypass_mode,
            ggpo_beta,
            ggpo_sigma,
            ggpo_conv,
            ggpo_conv_weight_sample_size
        )
        if self.module_type not in self.support_module:
            raise ValueError(f"{self.module_type} is not supported in T-LoRA algo.")
            
        self.lora_dim = lora_dim
        self.min_rank = min_rank
        self.sig_type = sig_type
        self.current_mask = None

        if self.module_type.startswith("conv"):
            in_dim = org_module.in_channels
            out_dim = org_module.out_channels
            k_size = org_module.kernel_size
            
            self.in_features = in_dim * torch.prod(torch.tensor(k_size)).item()
            self.out_features = out_dim
        else: # linear
            self.in_features = org_module.in_features
            self.out_features = org_module.out_features
            
        self.lora_q = nn.Linear(self.in_features, lora_dim, bias=False)
        self.lora_p = nn.Linear(lora_dim, self.out_features, bias=False)
        self.lora_lambda = nn.Parameter(torch.ones(1, lora_dim))

        # Generate initial weights using correct (out, in) dimensions
        q_init, p_init, lambda_init = F_tlora.weight_gen(
            self.out_features, self.in_features, lora_dim, sig_type
        )
        
        # Copy data. q_init is (rank, in), p_init is (out, rank)
        self.lora_q.weight.data.copy_(q_init)
        self.lora_p.weight.data.copy_(p_init)
        self.lora_lambda.data.copy_(lambda_init)

        self.register_buffer('base_q_weight', self.lora_q.weight.data.clone())
        self.register_buffer('base_p_weight', self.lora_p.weight.data.clone())
        self.register_buffer('base_lambda', self.lora_lambda.data.clone())
        
        if type(alpha) == torch.Tensor:
            alpha = alpha.detach().float().numpy()
        alpha = lora_dim if alpha is None or alpha == 0 else alpha
        self.scale = alpha / self.lora_dim
        self.register_buffer("alpha", torch.tensor(alpha))

    def set_mask(self, mask):
        self.current_mask = mask

    @classmethod
    def make_module_from_state_dict(
        cls, lora_name, orig_module, p_w, q_w, l, bq_w, bp_w, bl, alpha
    ):
        lora_dim = q_w.shape[0]
        module = cls(lora_name, orig_module, 1.0, lora_dim, float(alpha))
        module.lora_p.weight.data.copy_(p_w)
        module.lora_q.weight.data.copy_(q_w)
        module.lora_lambda.data.copy_(l)
        module.base_p_weight.copy_(bp_w)
        module.base_q_weight.copy_(bq_w)
        module.base_lambda.copy_(bl)
        return module
        
    def get_diff_weight(self, multiplier=1.0, shape=None, device=None):
        diff_matrix = F_tlora.diff_weight(
            self.lora_q.weight,
            self.lora_p.weight,
            self.lora_lambda,
            self.base_q_weight,
            self.base_p_weight,
            self.base_lambda,
            mask=self.current_mask
        ).to(device)

        if self.module_type.startswith("conv"):
            diff_weight = diff_matrix.view(self.shape)
        else:
            diff_weight = diff_matrix
            
        return diff_weight * self.scale * multiplier, None
        
    def get_merged_weight(self, multiplier=1.0, shape=None, device=None):
        diff_weight, _ = self.get_diff_weight(multiplier, shape, device)
        return self.org_weight.to(device) + diff_weight, None

    def forward(self, x):
        if self.module_dropout and self.training and torch.rand(1) < self.module_dropout:
            return self.org_forward(x)
            
        weight, bias = self.get_merged_weight(self.multiplier, device=x.device)
        return self.op(x, weight, bias, **self.kw_dict)