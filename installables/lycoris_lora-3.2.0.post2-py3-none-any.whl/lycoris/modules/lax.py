# lycoris/modules/lax.py

from threading import local

# Use thread-local storage to ensure cache is unique per thread,
# which is important for multi-GPU or concurrent data loading scenarios.
lax_thread_storage = local()

def get_lax_cache_key(lora_name: str) -> str:
    """
    Generates a cache key to group related LoRA modules.
    e.g., all attention projections within the same block will share a key.
    
    Example:
    'lora_unet_down_blocks_0_attentions_0_proj_in' -> 'lora_unet_down_blocks_0_attentions_0'
    'lora_unet_down_blocks_0_resnets_0_mlp_fc1' -> 'lora_unet_down_blocks_0_resnets_0_mlp'
    """
    parts = lora_name.split('_')
    # Heuristic: stop before the final projection/layer name
    stop_words = ['proj', 'fc1', 'fc2', 'to', 'linear1', 'linear2']
    key_parts = []
    for part in parts:
        # Check if the part starts with any of the stop words
        if any(part.startswith(sw) for sw in stop_words):
            break
        key_parts.append(part)
    return '_'.join(key_parts)