# lycoris/functional/tlora.py
import math
import torch
import gc

def weight_gen(out_features, in_features, rank=4, sig_type="last"):
    """
    Generates initial weights for T-LoRA (Ortho-LoRA) based on SVD.
    The SVD is performed on a matrix of shape (out_features, in_features).
    Returns q_init (rank, in), p_init (out, rank), lambda_init (1, rank).
    """
    base_m = torch.normal(
        size=(out_features, in_features), mean=0, std=1 / rank
    )
    u, s, vh = torch.linalg.svd(base_m) # vh is already V.T
    
    q_init, p_init, lambda_init = None, None, None

    if sig_type == 'principal':
        p_init = u[:, :rank].clone()
        q_init = vh[:rank, :].clone()
        lambda_init = s[None, :rank].clone()
    elif sig_type == 'last':
        p_init = u[:, -rank:].clone()
        q_init = vh[-rank:, :].clone()
        lambda_init = s[None, -rank:].clone()
    elif sig_type == 'middle':
        start_u = math.ceil((u.shape[1] - rank) / 2)
        p_init = u[:, start_u : start_u + rank].clone()
        start_v = math.ceil((vh.shape[0] - rank) / 2)
        q_init = vh[start_v : start_v + rank, :].clone()
        start_s = math.ceil((s.shape[0] - rank) / 2)
        lambda_init = s[None, start_s : start_s + rank].clone()
    else:
        raise ValueError(f"Unknown sig_type: {sig_type}")
    
    del u, s, vh, base_m
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    return q_init, p_init, lambda_init

def diff_weight(q, p, l, q_base, p_base, l_base, mask=None):
    """
    Calculates the weight difference for T-LoRA.
    ΔW = (P @ diag(λ*mask) @ Q) - (P_base @ diag(λ_base*mask) @ Q_base)
    """
    if mask is None:
        mask = 1.0
    
    l_masked = l * mask
    l_base_masked = l_base * mask
    
    # p is (out, rank), q is (rank, in)
    trainable_comp = p @ (torch.diag(l_masked.squeeze(0)) @ q)
    frozen_comp = p_base @ (torch.diag(l_base_masked.squeeze(0)) @ q_base)
    
    diff = trainable_comp - frozen_comp
    
    return diff